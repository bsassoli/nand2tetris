from typing import List


class Parser:
    def __init__(self, file: List[str]):

        if len(file):
            self.file = file
        else:
            raise FileExistsError("No contents in file")
        self.currentLine = 0
        self.currentCommand = ""
        self.nextCommand = ""
        self.isArithmetic = ["add", "sub", "neg",
                             "eq", "gt", "lt", "or", "and", "not"]
        self.commandsDict = {
            "push": "C_PUSH",
            "pop": "C_POP",
            "label": "C_LABEL",
            "goto": "C_GOTO",
            "if": "C_IF",
            "function": "C_FUNCTION",
            "return": "C_RETURN",
            "call": "C_CALL",
        }

    def __str__(self):
        pass

    def hasMoreCommands(self) -> bool:
        return self.currentLine <= len(self.file) - 1

    def advance(self) -> None:
        if self.hasMoreCommands():
            self.nextCommand = self.file[self.currentLine]
        self.currentLine += 1
        self.currentCommand = self.nextCommand

    def commandType(self):
        ctype = self.currentCommand.split()[0]
        if self.currentCommand in self.isArithmetic:
            return "C_ARITHMETIC"
        if ctype in self.commandsDict:
            return self.commandsDict[ctype]
        else:
            raise Exception(f"No such command type: {ctype}")

    def arg1(self):
        if self.commandType() == "C_ARITHMETIC":
            return self.currentCommand
        assert (
            self.commandType() != "C_RETURN"
        ), "self.arg1() should not be called with C_RETURN command types"
        return self.currentCommand.split()[1]

    def arg2(self):
        assert self.commandType() in [
            "C_PUSH",
            "C_POP",
            "C_CALL",
            "C_FUNCTION",
        ], "self.arg2() called with wrong command type"
        return self.currentCommand.split()[2]
